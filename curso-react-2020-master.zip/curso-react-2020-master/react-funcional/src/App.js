import React, { useState, useEffect } from 'react';

import ReducerHook from './reducer'

function App() {
    return (
      <ReducerHook />
    )
}

export default App;
